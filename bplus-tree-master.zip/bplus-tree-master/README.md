# B+ Tree Data Insertion and Deletion
## My B+ Tree Tuotial Link: http://www.sayef.tech/posts/2018/07/16/b-plus-tree-tutorial
The source code is well commented to understand which line does what. We can take input from file or manually, both the process is same as follwoing:

1. First give the number of pointers
2. Press 1 and a value for inserting the value
3. Press 2 for printing the B+ Tree
4. Press 3 and a existing value to be deleted

Note: If you want to take all those data from the console, just keep the input.txt blank
